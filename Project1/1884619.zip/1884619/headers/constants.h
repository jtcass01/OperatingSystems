#ifndef CONSTANTS
#define CONSTANTS

#define DEBUG 0

#endif
