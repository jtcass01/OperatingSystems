#ifndef REDUCER
#define REDUCER

#include "Message.h"

#endif
